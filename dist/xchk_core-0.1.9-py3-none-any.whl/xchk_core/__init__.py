default_app_config = 'xchk_core.apps.CheckerappConfig'
