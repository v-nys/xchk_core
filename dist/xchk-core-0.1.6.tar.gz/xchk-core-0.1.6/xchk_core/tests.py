from django.test import TestCase
from unittest.mock import Mock, patch, MagicMock
